# Bookstore Management System

A simple sample project using HTML, CSS, JavaScript, Node.js, Express, and MySQL.

## Run
1. Open the project in VS Code.
2. Open a terminal in `backend`.
3. Run `npm install`.
4. Run `npm start`.
5. Open `http://localhost:3000`.

This sample includes dashboard, inventory, customer management, order processing, and sales reporting. The demo stores data in memory for easy learning. A MySQL schema is included in `database/bookstore.sql`.
